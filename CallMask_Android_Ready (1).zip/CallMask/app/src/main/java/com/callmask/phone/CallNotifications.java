package com.callmask.phone;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Person;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.telecom.Call;

public final class CallNotifications {
    private static final String CHANNEL = "callmask_calls_v1";
    private static final int ID = 14142;
    private CallNotifications() {}

    static void createChannel(Context c) {
        NotificationChannel channel = new NotificationChannel(CHANNEL, "Телефонні дзвінки",
                NotificationManager.IMPORTANCE_HIGH);
        channel.setDescription("Вхідні та активні дзвінки CallMask");
        channel.setLockscreenVisibility(Notification.VISIBILITY_PRIVATE);
        ((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).createNotificationChannel(channel);
    }
    private static PendingIntent action(Context c, String a, int id) {
        Intent i = new Intent(c, CallActionReceiver.class).setAction(a);
        return PendingIntent.getBroadcast(c, id, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
    static void show(Context c, CallRepository.Session s) {
        NotificationManager nm = (NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (s == null) { nm.cancel(ID); return; }
        int state = s.call.getState();
        boolean ringing = state == Call.STATE_RINGING;
        PendingIntent answer = action(c, CallActionReceiver.ACCEPT, 1);
        PendingIntent reject = action(c, CallActionReceiver.REJECT, 2);
        PendingIntent hangup = action(c, CallActionReceiver.HANGUP, 3);
        Intent open = new Intent(c, CallScreenActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent launch = PendingIntent.getActivity(c, 4, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        String name = s.name(c);
        Notification.Builder builder = new Notification.Builder(c, CHANNEL)
                .setSmallIcon(com.callmask.phone.R.drawable.ic_callmask)
                .setContentTitle(name)
                .setContentText(ringing ? "Вхідний дзвінок" : "Телефонна розмова")
                .setCategory(Notification.CATEGORY_CALL)
                .setPriority(Notification.PRIORITY_MAX)
                .setVisibility(Notification.VISIBILITY_PRIVATE)
                .setOngoing(true)
                .setContentIntent(launch);
        if (ringing) builder.setFullScreenIntent(launch, true);
        if (Build.VERSION.SDK_INT >= 31) {
            Person caller = new Person.Builder().setName(name).setImportant(true).build();
            if (ringing) builder.setStyle(Notification.CallStyle.forIncomingCall(caller, reject, answer));
            else builder.setStyle(Notification.CallStyle.forOngoingCall(caller, hangup));
        } else {
            if (ringing) {
                builder.addAction(new Notification.Action.Builder(null, "Відхилити", reject).build());
                builder.addAction(new Notification.Action.Builder(null, "Відповісти", answer).build());
            } else {
                builder.addAction(new Notification.Action.Builder(null, "Завершити", hangup).build());
            }
        }
        try { nm.notify(ID, builder.build()); }
        catch (SecurityException ignored) { /* Notification permission can be denied. */ }
    }
}
