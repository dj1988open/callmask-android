package com.callmask.phone;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.role.RoleManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.CallLog;
import android.provider.Settings;
import android.telecom.TelecomManager;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Settings, real dialing keypad and sanitized local call history. */
public class MainActivity extends Activity {
    private static final int ASK_DIALER = 40, ASK_CALL = 41, ASK_CONTACTS = 42, ASK_LOG = 43, ASK_NOTIFICATIONS = 44;
    private EditText dial;
    private String pendingNumber;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        CallNotifications.createChannel(this);
        draw();
        if (getIntent() != null && Intent.ACTION_DIAL.equals(getIntent().getAction())
                && getIntent().getData() != null) {
            dial.setText(getIntent().getData().getSchemeSpecificPart());
        }
    }
    @Override public void onNewIntent(Intent i) {
        super.onNewIntent(i);
        setIntent(i);
        if (i != null && Intent.ACTION_DIAL.equals(i.getAction()) && i.getData() != null && dial != null)
            dial.setText(i.getData().getSchemeSpecificPart());
    }
    @Override protected void onResume() { super.onResume(); draw(); }

    private void draw() {
        String retainedDialNumber = dial == null ? "" : dial.getText().toString();
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Ui.BG);
        LinearLayout root = Ui.column(this);
        int space = Ui.dp(this,22);
        root.setPadding(space, Ui.dp(this,30), space, Ui.dp(this,30));
        scroll.addView(root);

        TextView logo = Ui.label(this, "◉  CALLMASK", 14, Ui.MINT, true);
        logo.setLetterSpacing(.16f);
        root.addView(logo);
        Ui.gap(root,16);
        root.addView(Ui.label(this,"Ти вирішуєш,\nколи відповідати.",30,Ui.WHITE,true));
        Ui.gap(root,10);
        root.addView(Ui.label(this,"Приватний телефонний застосунок. Один вибраний номер відображається як новий умовний номер при кожному дзвінку.",14,Ui.MUTED,false));
        Ui.gap(root,24);

        LinearLayout panel = Ui.column(this);
        panel.setPadding(Ui.dp(this,18),Ui.dp(this,18),Ui.dp(this,18),Ui.dp(this,18));
        panel.setBackground(Ui.bg(Ui.PANEL,22,this));
        root.addView(panel,Ui.full(this));
        boolean role = hasRole();
        boolean configured = MaskStore.hasTarget(this);
        boolean active = MaskStore.isEnabled(this);
        panel.addView(Ui.label(this,role ? "●  Основний телефон: CallMask" : "○  Основний телефон: Samsung / інший",15,role?Ui.MINT:Ui.MUTED,true));
        Ui.gap(panel,8);
        panel.addView(Ui.label(this,configured ? (active ? "Маскування увімкнено" : "Маскування вимкнено") : "Захищений номер ще не додано",17,Ui.WHITE,true));
        Ui.gap(panel,14);
        Button roleButton = Ui.button(this,role?"✓ CallMask обрано":"Зробити основним телефоном",Ui.MINT);
        roleButton.setEnabled(!role);
        panel.addView(roleButton, Ui.full(this));
        roleButton.setOnClickListener(v -> requestRole());
        Ui.gap(panel,10);
        Button edit = Ui.outline(this,configured ? "Змінити захищений номер (PIN)" : "Додати захищений номер");
        panel.addView(edit,Ui.full(this));
        edit.setOnClickListener(v -> accessSettings(this::inputTarget));
        if (configured) {
            Ui.gap(panel,10);
            Button toggle = Ui.outline(this,active ? "Вимкнути маскування (PIN)" : "Увімкнути маскування (PIN)");
            panel.addView(toggle,Ui.full(this));
            toggle.setOnClickListener(v -> accessSettings(() -> {
                MaskStore.setEnabled(this,!MaskStore.isEnabled(this));
                Toast.makeText(this,"Налаштування оновлено",Toast.LENGTH_SHORT).show();
                draw();
            }));
        }
        Ui.gap(root,16);
        Button demo = Ui.outline(this,"▶  Перевірити маскування без справжнього дзвінка");
        root.addView(demo, Ui.full(this));
        demo.setOnClickListener(v -> startActivity(new Intent(this, PreviewActivity.class)));
        if (role) {
            Ui.gap(root,10);
            Button resetDefault = Ui.outline(this,"Повернути стандартний Samsung Phone");
            root.addView(resetDefault, Ui.full(this));
            resetDefault.setOnClickListener(v -> {
                try { startActivity(new Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS)); }
                catch (Exception e) { toast("Налаштування → Програми → Стандартні програми → Телефон"); }
            });
        }
        Ui.gap(root,25);
        root.addView(Ui.label(this,"Набрати номер",21,Ui.WHITE,true));
        Ui.gap(root,12);
        dial = Ui.input(this,"Номер телефону");
        dial.setInputType(InputType.TYPE_CLASS_PHONE);
        dial.setText(retainedDialNumber);
        root.addView(dial,Ui.full(this));
        Ui.gap(root,12);
        String[][] keys = {{"1","2","3"},{"4","5","6"},{"7","8","9"},{"*","0","#"}};
        for (String[] group: keys) {
            LinearLayout r = Ui.row(this);
            for (String key: group) {
                Button b = Ui.outline(this,key);
                LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0,Ui.dp(this,55),1f);
                p.setMargins(Ui.dp(this,3),Ui.dp(this,3),Ui.dp(this,3),Ui.dp(this,3));
                r.addView(b,p);
                b.setOnClickListener(v -> dial.append(key));
            }
            root.addView(r,Ui.full(this));
        }
        Ui.gap(root,8);
        LinearLayout dialRow = Ui.row(this);
        Button del = Ui.outline(this,"⌫");
        Button call = Ui.button(this,"☎  Дзвонити",Ui.MINT);
        LinearLayout.LayoutParams small = new LinearLayout.LayoutParams(0,Ui.dp(this,55),1f);
        small.setMargins(0,0,Ui.dp(this,8),0);
        dialRow.addView(del,small);
        dialRow.addView(call,new LinearLayout.LayoutParams(0,Ui.dp(this,55),2f));
        root.addView(dialRow);
        del.setOnClickListener(v -> {
            int len = dial.length();
            if (len > 0) dial.getText().delete(len-1,len);
        });
        del.setOnLongClickListener(v -> { dial.setText(""); return true; });
        call.setOnClickListener(v -> makeCall());
        Ui.gap(root,22);
        Button recent = Ui.outline(this,"Останні дзвінки (прихований список)");
        root.addView(recent,Ui.full(this));
        recent.setOnClickListener(v -> openHistory());
        Ui.gap(root,10);
        Button contacts = Ui.outline(this,"Дозволити імена інших контактів");
        root.addView(contacts,Ui.full(this));
        contacts.setOnClickListener(v -> {
            if (checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED)
                Toast.makeText(this,"Доступ уже надано",Toast.LENGTH_SHORT).show();
            else requestPermissions(new String[]{Manifest.permission.READ_CONTACTS},ASK_CONTACTS);
        });
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            Ui.gap(root,10);
            Button notif = Ui.outline(this,"Дозволити сповіщення про дзвінки");
            root.addView(notif,Ui.full(this));
            notif.setOnClickListener(v -> requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},ASK_NOTIFICATIONS));
        }
        if (Build.VERSION.SDK_INT >= 34) {
            Ui.gap(root,10);
            Button full = Ui.outline(this,"Перевірити дозвіл на екран дзвінка");
            root.addView(full,Ui.full(this));
            full.setOnClickListener(v -> {
                Intent i = new Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT,
                        Uri.parse("package:" + getPackageName()));
                try { startActivity(i); }
                catch (Exception e) { toast("Не вдалося відкрити налаштування"); }
            });
        }
        Ui.gap(root,20);
        root.addView(Ui.label(this,
                "Важливо: це тестова версія. Номер, який бачиш на екрані, вигаданий і не призначений для зворотних дзвінків. Оригінальний номер не змінюється у мережі оператора, системному журналі, SMS, Bluetooth/автомобільних системах та сторонніх застосунках. Виклики WhatsApp і Telegram не підтримуються. У будь-який момент можна повернути Samsung Phone як основний застосунок.",
                12,Ui.MUTED,false));
        setContentView(scroll);
    }
    private boolean hasRole() {
        RoleManager r = getSystemService(RoleManager.class);
        return r != null && r.isRoleHeld(RoleManager.ROLE_DIALER);
    }
    private void requestRole() {
        RoleManager r = getSystemService(RoleManager.class);
        if (r != null && r.isRoleAvailable(RoleManager.ROLE_DIALER))
            startActivityForResult(r.createRequestRoleIntent(RoleManager.ROLE_DIALER),ASK_DIALER);
        else toast("Система не дозволяє змінити основний телефон");
    }
    private interface Next { void run(); }
    private void accessSettings(Next next) {
        if (!MaskStore.hasPin(this)) { next.run(); return; }
        EditText pin = Ui.input(this,"PIN");
        pin.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        new AlertDialog.Builder(this).setTitle("Введіть PIN для зміни")
                .setView(pin).setNegativeButton("Скасувати",null)
                .setPositiveButton("Продовжити",(d,w)-> {
                    if (MaskStore.checkPin(this,pin.getText().toString())) next.run();
                    else toast("Неправильний PIN");
                }).show();
    }
    private void inputTarget() {
        EditText number = Ui.input(this,"+1 780 ...");
        number.setInputType(InputType.TYPE_CLASS_PHONE);
        new AlertDialog.Builder(this).setTitle("Введіть номер для маскування")
                .setMessage("Номер залишиться прихованим у налаштуваннях після збереження.")
                .setView(number).setNegativeButton("Скасувати",null)
                .setPositiveButton("Далі",(d,w)-> {
                    String n = number.getText().toString().trim();
                    if (!MaskStore.validNumber(n)) { toast("Введіть номер із 7–15 цифр"); return; }
                    if (!MaskStore.hasPin(this)) setupPin(n);
                    else { MaskStore.saveTarget(this,n); draw(); toast("Захищений номер оновлено"); }
                }).show();
    }
    private void setupPin(String n) {
        EditText pin = Ui.input(this,"Створіть PIN (4–8 цифр)");
        pin.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        new AlertDialog.Builder(this).setTitle("Захистіть налаштування PIN-кодом")
                .setMessage("Цей PIN знадобиться для зміни номера або вимкнення маскування. Якщо забудете PIN, потрібно буде очистити дані застосунку.")
                .setView(pin).setNegativeButton("Скасувати",null)
                .setPositiveButton("Зберегти",(d,w)-> {
                    String p = pin.getText().toString();
                    if (!p.matches("[0-9]{4,8}")) { toast("PIN повинен містити 4–8 цифр"); return; }
                    MaskStore.createPin(this,p);
                    MaskStore.saveTarget(this,n);
                    draw(); toast("Захищений номер збережено");
                }).show();
    }
    private void makeCall() {
        String number = dial.getText().toString().trim();
        if (number.isEmpty()) { toast("Введіть номер"); return; }
        if (!hasRole()) { toast("Спершу виберіть CallMask як основний телефон"); requestRole(); return; }
        pendingNumber = number;
        if (checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CALL_PHONE},ASK_CALL);
            return;
        }
        placeCall(number);
    }
    private void placeCall(String number) {
        try {
            TelecomManager t = (TelecomManager)getSystemService(Context.TELECOM_SERVICE);
            t.placeCall(Uri.fromParts("tel",number,null),new Bundle());
        } catch (Exception e) { toast("Не вдалося почати дзвінок: перевірте дозволи"); }
    }
    private void openHistory() {
        if (checkSelfPermission(Manifest.permission.READ_CALL_LOG) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.READ_CALL_LOG},ASK_LOG);
            return;
        }
        showHistory();
    }
    private void showHistory() {
        StringBuilder out = new StringBuilder();
        SimpleDateFormat f = new SimpleDateFormat("dd.MM  HH:mm",Locale.getDefault());
        try (Cursor c = getContentResolver().query(CallLog.Calls.CONTENT_URI,
                new String[]{CallLog.Calls.NUMBER,CallLog.Calls.DATE,CallLog.Calls.TYPE,CallLog.Calls.CACHED_NAME},
                null,null,CallLog.Calls.DATE + " DESC")) {
            if (c != null) {
                int count=0;
                while (c.moveToNext() && count++ < 30) {
                    String num = c.getString(0);
                    String name = c.getString(3);
                    boolean masked = MaskStore.matches(this,num);
                    String shown = masked ? "Прихований контакт" : MaskStore.displayForOther(this,num,name);
                    int type=c.getInt(2);
                    String dir = type==CallLog.Calls.INCOMING_TYPE ? "↙" :
                            type==CallLog.Calls.OUTGOING_TYPE ? "↗" : "×";
                    out.append(dir).append("  ").append(shown).append("\n")
                            .append("     ").append(f.format(new Date(c.getLong(1)))).append("\n\n");
                }
            }
        } catch (SecurityException ex) { out.append("Недостатньо дозволів для журналу дзвінків."); }
        if (out.length()==0) out.append("Історії поки немає або вона недоступна.");
        new AlertDialog.Builder(this).setTitle("Останні дзвінки · CallMask")
                .setMessage(out.toString()).setPositiveButton("Закрити",null).show();
    }
    private void toast(String s) { Toast.makeText(this,s,Toast.LENGTH_LONG).show(); }
    @Override public void onRequestPermissionsResult(int code, String[] p, int[] results) {
        super.onRequestPermissionsResult(code,p,results);
        boolean granted = results.length>0 && results[0]==PackageManager.PERMISSION_GRANTED;
        if (code==ASK_CALL && granted && pendingNumber!=null) placeCall(pendingNumber);
        else if (code==ASK_LOG && granted) showHistory();
        else if (!granted) toast("Доступ не надано. Відповідна функція може не працювати.");
        draw();
    }
    @Override protected void onActivityResult(int req, int result, Intent data) {
        super.onActivityResult(req,result,data);
        if (req==ASK_DIALER) {
            draw();
            if (result==RESULT_OK && Build.VERSION.SDK_INT>=33 &&
                    checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, ASK_NOTIFICATIONS);
        }
    }
}
