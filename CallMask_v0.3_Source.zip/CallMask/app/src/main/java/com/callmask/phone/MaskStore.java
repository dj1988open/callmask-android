package com.callmask.phone;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.provider.ContactsContract;
import android.content.pm.PackageManager;
import android.Manifest;
import android.database.Cursor;
import android.telecom.Call;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Locale;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

/** Private, device-local configuration. Never sends numbers or call data over the network. */
public final class MaskStore {
    private static final String PREF = "callmask_local_settings";
    private static final SecureRandom RNG = new SecureRandom();
    private MaskStore() {}

    private static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }

    public static boolean hasTarget(Context c) {
        return !prefs(c).getString("target_number", "").isEmpty();
    }
    public static boolean isEnabled(Context c) {
        return hasTarget(c) && prefs(c).getBoolean("mask_enabled", true);
    }
    public static void setEnabled(Context c, boolean enabled) {
        prefs(c).edit().putBoolean("mask_enabled", enabled).apply();
    }
    public static boolean validNumber(String n) {
        if (n == null) return false;
        String d = n.replaceAll("[^0-9]", "");
        return d.length() >= 10 && d.length() <= 15;
    }
    public static boolean matches(Context c, String candidate) {
        if (!isEnabled(c) || candidate == null || candidate.isEmpty()) return false;
        String target = prefs(c).getString("target_number", "");
        if (target.isEmpty()) return false;
        // Never match just the last seven digits: unrelated area codes may share them.
        String a = digits(target), b = digits(candidate);
        String nanpA = canonicalNanp(a), nanpB = canonicalNanp(b);
        if (nanpA != null || nanpB != null)
            return nanpA != null && nanpA.equals(nanpB);
        // Conservative exact international match: miss an ambiguous call rather than
        // conceal a different caller with a similar local number.
        return a.length() >= 10 && a.equals(b);
    }
    private static String canonicalNanp(String digits) {
        if (digits.length() == 11 && digits.startsWith("1")) return digits.substring(1);
        return digits.length() == 10 ? digits : null;
    }
    private static String digits(String n) {
        return n == null ? "" : n.replaceAll("[^0-9]", "");
    }
    public static void saveTarget(Context c, String n) {
        if (!validNumber(n)) throw new IllegalArgumentException("Number must have 10-15 digits");
        prefs(c).edit().putString("target_number", n.trim()).putBoolean("mask_enabled", true).apply();
    }
    public static String newAlias(Context c) {
        // The displayed number is a visual placeholder only, never used for routing calls.
        // A new, different full-length number makes it harder to memorize on sight.
        SharedPreferences p = prefs(c);
        String last = p.getString("last_alias", "");
        String next;
        int[] areaCodes = {780,587,825,403,604,236,416,647,289,905,613,514,902,204,306};
        do {
            int area = areaCodes[RNG.nextInt(areaCodes.length)];
            int exchange = 200 + RNG.nextInt(800);
            int line = RNG.nextInt(10000);
            next = String.format(Locale.ROOT, "+1 (%03d) %03d-%04d", area, exchange, line);
        } while (next.equals(last));
        p.edit().putString("last_alias", next).apply();
        return next;
    }
    public static String numberFrom(Call.Details d) {
        if (d == null || d.getHandle() == null) return "";
        Uri u = d.getHandle();
        if (!"tel".equalsIgnoreCase(u.getScheme())) return "";
        String n = u.getSchemeSpecificPart();
        return n == null ? "" : n;
    }
    public static String displayForOther(Context c, String phone, String suggestedName) {
        if (phone == null) phone = "";
        if (matches(c, phone)) return "Прихований абонент";
        if (c.checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED
                && !phone.isEmpty()) {
            Uri lookup = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(phone));
            try (Cursor cursor = c.getContentResolver().query(lookup,
                    new String[]{ContactsContract.PhoneLookup.DISPLAY_NAME}, null, null, null)) {
                if (cursor != null && cursor.moveToFirst()) {
                    String name = cursor.getString(0);
                    if (name != null && !name.isEmpty()) return name;
                }
            } catch (Exception ignored) { }
        }
        if (suggestedName != null && !suggestedName.trim().isEmpty()) return suggestedName;
        return phone.isEmpty() ? "Невідомий номер" : phone;
    }
    public static void createPin(Context c, String pin) {
        if (pin == null || !pin.matches("[0-9]{4,8}")) throw new IllegalArgumentException("PIN: 4-8 digits");
        byte[] salt = new byte[16];
        RNG.nextBytes(salt);
        prefs(c).edit().putString("pin_salt", hex(salt))
                .putString("pin_hash", slowHash(salt, pin))
                .putString("pin_algo", "pbkdf2-sha256")
                .putInt("pin_failures", 0).putLong("pin_lock_until", 0).apply();
    }
    public static boolean hasPin(Context c) {
        return !prefs(c).getString("pin_hash", "").isEmpty();
    }
    public static boolean checkPin(Context c, String pin) {
        SharedPreferences p = prefs(c);
        if (System.currentTimeMillis() < p.getLong("pin_lock_until", 0)) return false;
        String salt = p.getString("pin_salt", "");
        String expected = p.getString("pin_hash", "");
        if (salt.isEmpty() || expected.isEmpty() || pin == null) return false;
        boolean correct = false;
        boolean legacy = !"pbkdf2-sha256".equals(p.getString("pin_algo", ""));
        try {
            byte[] bytes = unhex(salt);
            String computed = legacy ? legacyHash(bytes, pin) : slowHash(bytes, pin);
            correct = MessageDigest.isEqual(unhex(expected), unhex(computed));
        } catch (Exception ignored) { }
        if (correct) {
            if (legacy) createPin(c, pin); // Migrate previous v0.2 PIN after successful entry.
            p.edit().putInt("pin_failures", 0).putLong("pin_lock_until", 0).apply();
        } else {
            int attempts = p.getInt("pin_failures", 0) + 1;
            if (attempts >= 5) p.edit().putInt("pin_failures", 0)
                    .putLong("pin_lock_until", System.currentTimeMillis() + 60_000L).apply();
            else p.edit().putInt("pin_failures", attempts).apply();
        }
        return correct;
    }
    private static String slowHash(byte[] salt, String pin) {
        PBEKeySpec spec = new PBEKeySpec(pin.toCharArray(), salt, 120_000, 256);
        try { return hex(SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded()); }
        catch (Exception e) { throw new IllegalStateException(e); }
        finally { spec.clearPassword(); }
    }
    private static String legacyHash(byte[] salt, String pin) {
        try {
            MessageDigest d = MessageDigest.getInstance("SHA-256");
            d.update(salt);
            return hex(d.digest(pin.getBytes(java.nio.charset.StandardCharsets.UTF_8)));
        } catch (Exception e) { throw new IllegalStateException(e); }
    }
    private static String hex(byte[] a) {
        StringBuilder s = new StringBuilder(a.length * 2);
        for (byte b: a) s.append(String.format(Locale.ROOT, "%02x", b & 0xff));
        return s.toString();
    }
    private static byte[] unhex(String s) {
        byte[] a = new byte[s.length()/2];
        for (int i = 0; i < a.length; i++) a[i] = (byte) Integer.parseInt(s.substring(i*2,i*2+2),16);
        return a;
    }
}
