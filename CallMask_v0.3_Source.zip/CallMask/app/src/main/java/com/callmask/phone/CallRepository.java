package com.callmask.phone;

import android.content.Context;
import android.telecom.Call;
import android.telecom.InCallService;
import android.os.Handler;
import android.os.Looper;
import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

/** Tracks phone calls only while CallMask is the default in-call application. */
public final class CallRepository {
    private static final IdentityHashMap<Call, Session> calls = new IdentityHashMap<>();
    private static final ArrayList<Call> order = new ArrayList<>();
    private static final CopyOnWriteArrayList<Runnable> listeners = new CopyOnWriteArrayList<>();
    private static final Handler handler = new Handler(Looper.getMainLooper());
    private static CallMaskService service;

    private CallRepository() {}
    public static final class Session {
        public final Call call;
        public String alias;
        public boolean masked;
        public String phone;
        public Session(Call call, Context c) {
            this.call = call;
            this.phone = MaskStore.numberFrom(call.getDetails());
            this.masked = MaskStore.matches(c, phone);
            this.alias = this.masked ? MaskStore.newAlias(c) : null; // stable for one masked call
        }
        public void update(Context c) {
            this.phone = MaskStore.numberFrom(call.getDetails());
            this.masked = MaskStore.matches(c, phone);
            if (this.masked && this.alias == null) this.alias = MaskStore.newAlias(c);
        }
        public String name(Context c) {
            if (masked) return alias;
            String suggested = call.getDetails() == null ? null : call.getDetails().getCallerDisplayName();
            return MaskStore.displayForOther(c, phone, suggested);
        }
    }
    public static void setService(CallMaskService s) { service = s; }
    public static CallMaskService service() { return service; }
    public static void add(Call c, Context context) {
        if (calls.containsKey(c)) return;
        calls.put(c, new Session(c, context));
        order.add(c);
        changed();
    }
    public static void refresh(Call c, Context context) {
        Session s = calls.get(c);
        if (s != null) s.update(context);
        changed();
    }
    public static void remove(Call c) {
        calls.remove(c);
        order.remove(c);
        changed();
    }
    public static Session current() {
        for (int i=order.size()-1; i>=0; i--) {
            Call c = order.get(i);
            if (c.getState() == Call.STATE_RINGING) return calls.get(c);
        }
        for (int i=order.size()-1; i>=0; i--) {
            Call c = order.get(i);
            if (c.getState() == Call.STATE_ACTIVE) return calls.get(c);
        }
        for (int i=order.size()-1; i>=0; i--) {
            Call c = order.get(i);
            if (c.getState() != Call.STATE_DISCONNECTED) return calls.get(c);
        }
        return null;
    }
    public static void clear() {
        calls.clear();
        order.clear();
        changed();
    }
    public static void subscribe(Runnable r) { listeners.addIfAbsent(r); }
    public static void unsubscribe(Runnable r) { listeners.remove(r); }
    public static void changed() {
        handler.post(() -> {
            if (service != null) service.showCallNotification();
            for (Runnable r: listeners) r.run();
        });
    }
}
