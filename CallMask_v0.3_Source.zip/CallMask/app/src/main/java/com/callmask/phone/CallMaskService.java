package com.callmask.phone;

import android.telecom.Call;
import android.telecom.InCallService;
import android.content.Intent;

public class CallMaskService extends InCallService {
    private final java.util.IdentityHashMap<Call, Call.Callback> observers = new java.util.IdentityHashMap<>();
    @Override public void onCreate() {
        super.onCreate();
        Diagnostics.serviceState(this, true);
        CallRepository.setService(this);
        CallNotifications.createChannel(this);
    }
    @Override public void onCallAdded(Call call) {
        super.onCallAdded(call);
        CallRepository.add(call, this);
        Diagnostics.event(this, "call_added");
        Call.Callback observer = new Call.Callback() {
            @Override public void onStateChanged(Call c, int state) { CallRepository.refresh(c, CallMaskService.this); }
            @Override public void onDetailsChanged(Call c, Call.Details details) { CallRepository.refresh(c, CallMaskService.this); }
        };
        observers.put(call, observer);
        call.registerCallback(observer);
        showCallNotification();
    }
    @Override public void onCallRemoved(Call call) {
        Call.Callback observer = observers.remove(call);
        if (observer != null) call.unregisterCallback(observer);
        CallRepository.remove(call);
        Diagnostics.event(this, "call_removed");
        super.onCallRemoved(call);
    }
    void showCallNotification() { CallNotifications.show(this, CallRepository.current()); }
    @Override public void onBringToForeground(boolean showDialpad) {
        super.onBringToForeground(showDialpad);
        Diagnostics.event(this, "system_requested_call_screen");
        try {
            Intent i = new Intent(this, CallScreenActivity.class)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(i);
        } catch (RuntimeException e) {
            Diagnostics.event(this, "call_screen_launch_failed");
        }
    }
    @Override public void onDestroy() {
        for (java.util.Map.Entry<Call, Call.Callback> e: observers.entrySet()) {
            e.getKey().unregisterCallback(e.getValue());
        }
        observers.clear();
        Diagnostics.serviceState(this, false);
        CallRepository.setService(null);
        CallRepository.clear();
        CallNotifications.show(this, null);
        super.onDestroy();
    }
}
