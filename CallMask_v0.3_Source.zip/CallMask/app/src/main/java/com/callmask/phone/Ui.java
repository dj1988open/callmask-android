package com.callmask.phone;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

public final class Ui {
    public static final int BG = Color.rgb(11, 18, 32);
    public static final int PANEL = Color.rgb(22, 33, 51);
    public static final int WHITE = Color.rgb(245, 249, 255);
    public static final int MUTED = Color.rgb(157, 178, 196);
    public static final int MINT = Color.rgb(104, 224, 194);
    public static final int RED = Color.rgb(234, 95, 107);
    private Ui() {}

    public static int dp(Context c, float d) {
        return (int)(d * c.getResources().getDisplayMetrics().density + 0.5f);
    }
    public static GradientDrawable bg(int fill, int cornerDp, Context c) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(dp(c, cornerDp));
        return d;
    }
    public static LinearLayout column(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }
    public static LinearLayout row(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }
    public static TextView label(Context c, String s, float sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    public static Button button(Context c, String label, int color) {
        Button b = new Button(c);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(15);
        b.setTextColor(BG);
        b.setBackground(bg(color, 16, c));
        b.setPadding(dp(c,10), dp(c,12), dp(c,10), dp(c,12));
        return b;
    }
    public static Button outline(Context c, String label) {
        Button b = button(c,label,PANEL);
        b.setTextColor(WHITE);
        return b;
    }
    public static EditText input(Context c, String hint) {
        EditText t = new EditText(c);
        t.setSingleLine(true);
        t.setTextColor(WHITE);
        t.setHintTextColor(MUTED);
        t.setTextSize(18);
        t.setHint(hint);
        t.setBackground(bg(PANEL,14,c));
        t.setPadding(dp(c,16),dp(c,14),dp(c,16),dp(c,14));
        return t;
    }
    public static void gap(LinearLayout p, int dp) {
        View v = new View(p.getContext());
        p.addView(v,new LinearLayout.LayoutParams(1,dp(p.getContext(),dp)));
    }
    public static LinearLayout.LayoutParams full(Context c) {
        return new LinearLayout.LayoutParams(-1,-2);
    }
}
