package com.callmask.phone;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.telecom.Call;
import android.telecom.VideoProfile;

/** Notification actions never embed the actual caller number. */
public class CallActionReceiver extends BroadcastReceiver {
    public static final String ACCEPT = "com.callmask.phone.ACTION_ACCEPT";
    public static final String REJECT = "com.callmask.phone.ACTION_REJECT";
    public static final String HANGUP = "com.callmask.phone.ACTION_HANGUP";
    @Override public void onReceive(Context context, Intent intent) {
        CallRepository.Session session = CallRepository.current();
        if (session == null || intent == null) return;
        Call c = session.call;
        switch (intent.getAction() == null ? "" : intent.getAction()) {
            case ACCEPT:
                if (c.getState() == Call.STATE_RINGING) c.answer(VideoProfile.STATE_AUDIO_ONLY);
                break;
            case REJECT:
                if (c.getState() == Call.STATE_RINGING) c.reject(false, null);
                break;
            case HANGUP:
                c.disconnect();
                break;
            default: break;
        }
    }
}
