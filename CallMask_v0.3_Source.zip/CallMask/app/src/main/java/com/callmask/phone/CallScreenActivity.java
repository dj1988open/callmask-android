package com.callmask.phone;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.telecom.Call;
import android.telecom.CallAudioState;
import android.telecom.VideoProfile;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Replaces the in-call screen. No caller's original number is drawn if masked. */
public class CallScreenActivity extends Activity {
    private final Runnable refresh = this::render;
    private LinearLayout root;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean keypadVisible;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        setShowWhenLocked(true);
        setTurnScreenOn(true);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Ui.BG);
        root = Ui.column(this);
        root.setPadding(Ui.dp(this,24),Ui.dp(this,50),Ui.dp(this,24),Ui.dp(this,24));
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        scroll.addView(root);
        setContentView(scroll);
    }
    @Override protected void onResume() {
        super.onResume();
        Diagnostics.event(this, "call_screen_visible");
        CallRepository.subscribe(refresh);
        render();
    }
    @Override protected void onPause() {
        CallRepository.unsubscribe(refresh);
        super.onPause();
    }
    private void render() {
        if (isFinishing() || root == null) return;
        CallRepository.Session session = CallRepository.current();
        if (session == null) { finish(); return; }
        Call call = session.call;
        int state = call.getState();
        boolean ringing = state == Call.STATE_RINGING;
        boolean active = state == Call.STATE_ACTIVE;
        root.removeAllViews();
        root.addView(Ui.label(this,"CALLMASK",15,Ui.MINT,true));
        Ui.gap(root,24);
        TextView circle = Ui.label(this,"◉",80,Ui.MINT,true);
        circle.setGravity(Gravity.CENTER);
        root.addView(circle);
        Ui.gap(root,20);
        TextView name = Ui.label(this,session.name(this),32,Ui.WHITE,true);
        name.setGravity(Gravity.CENTER);
        root.addView(name);
        Ui.gap(root,10);
        String status = ringing ? "Вхідний дзвінок" : active ? "Розмова триває" :
                state == Call.STATE_DIALING ? "Набираємо номер..." :
                state == Call.STATE_CONNECTING ? "Підключення..." : "Телефонний дзвінок";
        TextView subtitle = Ui.label(this,status,16,Ui.MUTED,false);
        subtitle.setGravity(Gravity.CENTER);
        root.addView(subtitle);
        Ui.gap(root,30);
        if (ringing) {
            Button reject = Ui.button(this,"Відхилити",Ui.RED);
            Button answer = Ui.button(this,"Відповісти",Ui.MINT);
            root.addView(answer,Ui.full(this));
            Ui.gap(root,12);
            root.addView(reject,Ui.full(this));
            answer.setOnClickListener(v -> call.answer(VideoProfile.STATE_AUDIO_ONLY));
            reject.setOnClickListener(v -> call.reject(false,null));
        } else {
            if (active) {
                LinearLayout controls = Ui.row(this);
                CallMaskService svc = CallRepository.service();
                CallAudioState audio = svc == null ? null : svc.getCallAudioState();
                boolean mute = audio != null && audio.isMuted();
                boolean speaker = audio != null && (audio.getRoute() & CallAudioState.ROUTE_SPEAKER) != 0;
                Button muteB = Ui.outline(this,mute ? "Мікрофон: ВКЛ" : "Вимкнути мікрофон");
                Button speakerB = Ui.outline(this,speaker ? "Динамік: ВКЛ" : "Увімкнути динамік");
                LinearLayout.LayoutParams half = new LinearLayout.LayoutParams(0,Ui.dp(this,65),1f);
                half.setMargins(Ui.dp(this,4),0,Ui.dp(this,4),0);
                controls.addView(muteB,half);
                LinearLayout.LayoutParams half2 = new LinearLayout.LayoutParams(0,Ui.dp(this,65),1f);
                half2.setMargins(Ui.dp(this,4),0,Ui.dp(this,4),0);
                controls.addView(speakerB,half2);
                root.addView(controls);
                muteB.setOnClickListener(v -> { if (svc!=null) svc.setMuted(!mute); handler.postDelayed(this::render,250); });
                speakerB.setOnClickListener(v -> {
                    if (svc!=null) svc.setAudioRoute(speaker ? CallAudioState.ROUTE_EARPIECE : CallAudioState.ROUTE_SPEAKER);
                    handler.postDelayed(this::render,250);
                });
                Ui.gap(root,12);
                Button keypad = Ui.outline(this,keypadVisible ? "Сховати клавіатуру" : "Клавіатура DTMF");
                root.addView(keypad,Ui.full(this));
                keypad.setOnClickListener(v -> { keypadVisible=!keypadVisible; render(); });
                if (keypadVisible) addDtmf(call);
                Ui.gap(root,12);
            }
            Button hang = Ui.button(this,"Завершити дзвінок",Ui.RED);
            root.addView(hang,Ui.full(this));
            hang.setOnClickListener(v -> call.disconnect());
        }
        Ui.gap(root,25);
        root.addView(Ui.label(this,"Номер телефону не змінюється у мобільній мережі.",12,Ui.MUTED,false));
    }
    private void addDtmf(Call call) {
        Ui.gap(root,12);
        String[][] digits = {{"1","2","3"},{"4","5","6"},{"7","8","9"},{"*","0","#"}};
        for (String[] row: digits) {
            LinearLayout line = Ui.row(this);
            for (String digit: row) {
                Button btn=Ui.outline(this,digit);
                LinearLayout.LayoutParams size=new LinearLayout.LayoutParams(0,Ui.dp(this,48),1f);
                size.setMargins(Ui.dp(this,3),Ui.dp(this,3),Ui.dp(this,3),Ui.dp(this,3));
                line.addView(btn,size);
                btn.setOnClickListener(v -> {
                    call.playDtmfTone(digit.charAt(0));
                    handler.postDelayed(call::stopDtmfTone,180);
                });
            }
            root.addView(line,Ui.full(this));
        }
    }
}
