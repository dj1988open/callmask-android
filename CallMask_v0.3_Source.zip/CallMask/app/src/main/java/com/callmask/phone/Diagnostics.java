package com.callmask.phone;

import android.app.NotificationManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;

/** Local-only anonymous events to distinguish role selection from actual Telecom callbacks. */
public final class Diagnostics {
    private static final String NAME = "callmask_diagnostics";
    private Diagnostics() { }
    private static SharedPreferences p(Context c) {
        return c.getApplicationContext().getSharedPreferences(NAME, Context.MODE_PRIVATE);
    }
    public static void event(Context c, String key) {
        long now = System.currentTimeMillis();
        p(c).edit().putString("last_event", key).putLong("last_time", now)
                .putLong("event_" + key, now).apply();
    }
    public static void serviceState(Context c, boolean active) {
        p(c).edit().putBoolean("service_active", active).apply();
        event(c, active ? "service_connected" : "service_disconnected");
    }
    // This is an in-process check: a preference could become stale after a crash.
    public static boolean serviceActive(Context c) { return CallRepository.service() != null; }
    public static long eventTime(Context c, String event) { return p(c).getLong("event_" + event, 0); }
    public static String lastEvent(Context c) { return p(c).getString("last_event", "no_event"); }
    public static long lastTime(Context c) { return p(c).getLong("last_time", 0); }
    public static boolean notificationsEnabled(Context c) {
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        return nm != null && nm.areNotificationsEnabled();
    }
    public static boolean fullScreenAllowed(Context c) {
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        return Build.VERSION.SDK_INT < 34 || (nm != null && nm.canUseFullScreenIntent());
    }
}
