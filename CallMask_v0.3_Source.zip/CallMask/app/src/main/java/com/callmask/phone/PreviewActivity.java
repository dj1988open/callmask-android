package com.callmask.phone;

import android.app.Activity;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Safe visual demo; never answers, declines, or initiates real phone calls. */
public class PreviewActivity extends Activity {
    private LinearLayout root;
    private String currentAlias;
    private int counter;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Ui.BG);
        root = Ui.column(this);
        root.setPadding(Ui.dp(this,24), Ui.dp(this,45), Ui.dp(this,24), Ui.dp(this,24));
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        scroll.addView(root);
        setContentView(scroll);
        nextCall();
    }

    private void nextCall() {
        currentAlias = MaskStore.newAlias(this);
        counter++;
        draw();
    }

    private void draw() {
        root.removeAllViews();
        root.addView(Ui.label(this,"CALLMASK · DEMO",15,Ui.MINT,true));
        Ui.gap(root,15);
        TextView safety = Ui.label(this,
                "Демонстрація: це НЕ справжній виклик і нічого не змінює у системі.",
                14,Ui.MUTED,false);
        safety.setGravity(Gravity.CENTER);
        root.addView(safety);
        Ui.gap(root,28);
        TextView avatar = Ui.label(this,"◉",82,Ui.MINT,true);
        avatar.setGravity(Gravity.CENTER);
        root.addView(avatar);
        Ui.gap(root,20);
        TextView name = Ui.label(this,currentAlias,29,Ui.WHITE,true);
        name.setGravity(Gravity.CENTER);
        root.addView(name);
        Ui.gap(root,10);
        TextView description = Ui.label(this,"Вхідний дзвінок · тест №"+counter,16,Ui.MUTED,false);
        description.setGravity(Gravity.CENTER);
        root.addView(description);
        Ui.gap(root,30);
        Button next = Ui.button(this,"Наступний виклик → інший номер",Ui.MINT);
        root.addView(next,Ui.full(this));
        next.setOnClickListener(v -> nextCall());
        Ui.gap(root,12);
        Button close = Ui.outline(this,"Повернутися до налаштувань");
        root.addView(close,Ui.full(this));
        close.setOnClickListener(v -> finish());
        Ui.gap(root,22);
        TextView disclaimer = Ui.label(this,
                "Цей умовний номер згенеровано лише для екрана. Він не є перевіреним номером абонента — не телефонуйте на нього.",
                12,Ui.MUTED,false);
        disclaimer.setGravity(Gravity.CENTER);
        root.addView(disclaimer);
    }
}
